import {mostrar} from './helper.js' 

// ev es la variable que recoge  el objeto evento, con todas sus propiedades.
// la puedo llamar como quiera
function saludar(ev) {
	console.dir(ev.target.id)
	switch (ev.target.id) {
		case 'btn_saludar':
			mostrar('Hola amigos')	
			break;
		case 'btn_despedir':
			mostrar('Adios amigos')
			break;	
		default:
			break;
	}
}

// ACceder al elemento del DOM y lo guardamos en una variable. Me devuelve el NODO correspondiente al bottom

let btnSaludar = document.querySelector('#btn_saludar')
let btnDespedirse = document.querySelector('#btn_despedir')

// Con esta propiedad (addEventListener) puedo asociar cualquier evento con cualquier función.
// 2 parametros: nombre_del_evento y el metodo que queremos que responda al evento.
// Esta función, en realidad es un callback, la ejecuta addEventListener, no lleva parentesis

btnSaludar.addEventListener('click',saludar)

//btnDespedirse.addEventListener('click',() => mostrar('Adios amigos'))

btnDespedirse.addEventListener('click', saludar)

// El navegador, cada vez qeu  ejecuta esta función, le pasa un parametro. 
// El parametro va a ser un objeto de la clase evento