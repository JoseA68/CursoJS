
function saludar() {

	let nombre = window.prompt('Dime tu nombre')
	window.alert('Hola ' + nombre)
}
function irBanco() {

	const url = 'https://www.bbva.es/particulares'
	window.location.assign(url)
}
