// acceder al objeto formulario
function app () {
	const formCursos = document.querySelector('#formCursos')
	// crear un objeto que va a almacenar todos los datos del formulario
	// lo podriamos hacer a partir del formulario, pero lo vamos a hacer
	// con el proceso standard del DOM.
	//  
	const oDatos = {}
	const inNombre = document.querySelector('#nombre')
	const url = 'https://jsonplaceholder'


	console.dir(formCursos)

	formCursos.addEventListener('submit', enviar)
	inNombre.addEventListener('change',cambio)
	inNombre.addEventListener('input', cambio)

	function cambio(ev) {
		console.log(ev.target.value)
	}

	function enviar(ev) {

		// bloqueo el envio, con el Metodo preventDEfault

		ev.preventDefault()
		console.log('Enviando')
		oDatos.nombre = document.querySelector('#nombre').value
		oDatos.email = document.querySelector('#email').value
		oDatos.passw = document.querySelector('#passw').value
		oDatos.coments = document.querySelector('#coments').value
		oDatos.isOk = document.querySelector('#isOk').checked
		// crear una funcion llamada getSelect, que recibe como parametro el id con la almohadilla
		//oDatos.curso = getSelect('#curso')
		oDatos.curso = document.querySelector('#curso').value
		oDatos.turno = getRadio('turno')
		console.dir(oDatos)
		// envio  a un servidor
		fetch(url,{method: 'post', body: oDatos})
		.then((response) => {return response.json()})
		.then((data) =>{console.log(data)})
	}

	function getRadio(name) {
		const aRadio = document.querySelectorAll(`[name="${name}"]`)
		console.dir(aRadio)

		for (let i = 0; i < aRadio.length; i++) {
			const item = aRadio[i];
			if (item.checked) {

			}
			
		}
	}
	function getSelect(id) {
		const select = document.querySelector(id)
		console.dir(select[select.selectedi].value)
		console.dir(select[select.selectedIndex].textContent)
		return select[select.selectedIndex].value
	}
}
// Espero a que se carge todo el dom, para ejecutar la función app donde englobo todo

document.addEventListener('DOMContentLoaded', app)