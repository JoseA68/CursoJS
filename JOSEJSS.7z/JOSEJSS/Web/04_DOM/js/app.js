
function saludar() {
	const msg = 'Hola <b>amigos</b>'
	//console.log(document)
	//console.dir(document)
	let output = 	document.querySelector('#output')
	let parrafosInfo = document.querySelectorAll('.Info')
	let parrafo1 = document.querySelector('#p01')
	console.dir(output)
	console.dir(parrafosInfo)
	output.innerHTML = msg
	parrafosInfo.forEach(
	//	item => item.outerHTML = ''
		item => item.classList.toggle('hide')
	)
	


}
