import {mostrar} from './helper.js' 

function saludar() {
	mostrar('Soy la funcion saludar en un fichero')
}
saludar()