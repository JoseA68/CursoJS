export let mostrar = msg => console.log(msg)

let mostrarMay = msg => console.log(msg.toUpperCase())